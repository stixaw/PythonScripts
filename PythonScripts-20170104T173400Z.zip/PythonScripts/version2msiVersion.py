import os
import sys

version = '7.1'

msiVersion = version.replace('.', '_')
print msiVersion