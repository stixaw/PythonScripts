def HappyBirthday(name, age):
	print "Happy Birthday, " + name + " wow I can't believe you are ", age, " today!"

def HappyBirthday2(name = 'John', age= '12'):
	print "Happy Birthday, " + name + " wow I can't believe you are ", age, " today!"

HappyBirthday('Angel', 50)

HappyBirthday2( age = '14')
