import os
import sys
import string


BUILDDIR2 = '2011-06-02_06-45'


BUILDDIR1= BUILDDIR2.replace("_",'')

print 'BUILDDIR1 = ', BUILDDIR1

BUILDDIR = BUILDDIR1.replace("-",'')


print 'BUILDDIR = ', BUILDDIR