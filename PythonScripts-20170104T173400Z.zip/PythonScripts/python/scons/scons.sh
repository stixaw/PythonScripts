#!/bin/sh
python -c "import os; import sys; sys.path = [ os.environ['TOP'] + '/build/scons' ] + sys.path; import SCons.Script; SCons.Script.main()" -u $*
