import array
import os
import shutil
import string
import glob
import re
import subprocess
import sys

def Glob(env, pattern):
	path = string.replace(env.GetBuildPath('SConscript'), 'SConscript', '')
	
	result = []
	for i in glob.glob(path + pattern):
		result.append(string.replace(i, path, ''))
		
	return result

def GetLibPath(libpaths, libs):
    paths = []
    for lib in libs:
	for path in libpaths:
	    if path.find(lib) >= 0:
		paths += [path]
    return paths

def MfcLib(target_info):
    if target_info['os'] in ['win32', 'win64']:
	if target_info['build_type'] == 'debug':
	    return ['nafxcwd']
	else:
	    return ['nafxcw']
    elif target_info['os'] == 'wince':
	if target_info['build_type'] == 'debug':
	    return ['uafxwced']
	else:
	    return ['uafxwce']
    else:
	return []

class BinToHex:
    "A bin->hex object for use in Command()."
    def __init__(self, arrayName):
	self.arrayName = arrayName

    def __call__(self, env, target, source):
	f = open(str(source[0]), 'rb')
	data = array.array('B', f.read())
	f.close()
	f = open(str(target[0]), 'wt')
	f.write('unsigned char %s[] = {' % (self.arrayName, ))
	for i in range(len(data)):
	    if i % 16 == 0:
		f.write('\n')
	    f.write('0x%02x, ' % int(data[i]))
	f.write('\n};\n\n#define %s_Size %d\n' % (self.arrayName, len(data)))
	f.close()
	return None

class Dos32Bind:
    def RunSB(self, target, source, env):
	shell = os.environ['COMSPEC']
	top = os.environ['TOP']
	args = [shell, '/c', 'start', '/wait', '%s\\build\\dos32a\\binw\\sb.exe' % (top,),
	    '-R', str(target[0])]
	os.spawnv(os.P_WAIT, shell, args)

    def ActionString(self, target, source, env):
	return 'DOS/32 bind ' + str(target[0])

    def Action(self, env):
	return env.Action(self.RunSB, self.ActionString)

class Dos32Configure:
    def RunSS(self, target, source, env):
	shell = os.environ['COMSPEC']
	top = os.environ['TOP']
	args = [shell, '/c', 'start', '/wait', '%s\\build\\dos32a\\binw\\ss.exe' % (top,),
	    str(target[0]), '%s\\build\\dos32a\\binw\\dos32.d32' % (top, )]
	os.spawnv(os.P_WAIT, shell, args)

    def ActionString(self, target, source, env):
	return 'DOS/32 configure ' + str(target[0])

    def Action(self, env):
	return env.Action(self.RunSS, self.ActionString)

class WDosXBind:
    def RunStubIt(self, target, source, env):
	shell = os.environ['COMSPEC']
	top = os.environ['TOP']
	args = [shell, '/c', 'start', '/wait', '%s\\build\\wdosx\\stubit.exe' % (top,), str(target[0])]
	os.spawnv(os.P_WAIT, shell, args)

    def ActionString(self, target, source, env):
	return 'WDOSX bind ' + str(target[0])

    def Action(self, env):
	return env.Action(self.RunStubIt, self.ActionString)

class WDosXConfigure:
    def RunWDXCustD(self, target, source, env):
	shell = os.environ['COMSPEC']
	top = os.environ['TOP']
	args = [shell, '/c', 'start', '/wait', '%s\\build\\wdosx\\wdxcustd.exe' % (top,),
	    '-f', str(target[0]), '-x', '5M']
	os.spawnv(os.P_WAIT, shell, args)

    def ActionString(self, target, source, env):
	return 'WDOSX configure ' + str(target[0])

    def Action(self, env):
	return env.Action(self.RunWDXCustD, self.ActionString)

def Stub(env, target_info):
    "A stub action object for use in AddPostAction()."
    if target_info['build_type'] == 'release':
	if target_info['compiler'] == 'watcom':
	    return env.Action([ 'start /wait build\\32lite\\32lite.exe -m $TARGET',
				Dos32Bind().Action(env),
				Dos32Configure().Action(env)])
	elif target_info['compiler'] == 'djgpp':
	    return env.Action([WDosXBind().Action(env), WDosXConfigure().Action(env)])
	elif target_info['compiler'] in ['msc', 'watcom-d16'] and target_info['cpu'] == 'x86':
	    return env.Action('start /wait build\\upx\\win32\\upx -9 --no-color $TARGET')
	elif target_info['os'] == 'linux' and target_info['cpu'] == 'x86':
	    return env.Action('./build/upx/linux/upx -9 --no-color $TARGET')
	else:
	    return env.Action('')
    else:
	# For Brian
	if target_info['compiler'] == 'djgpp':
	    return env.Action([WDosXBind().Action(env), WDosXConfigure().Action(env)])
	else:
	    return env.Action('')

class Nm:
    def Run(self, target, source, env):
	shell = os.environ['COMSPEC']
	args = [shell, '/c', 'nm.exe', '-C', '-g', '-n', str(target[0]), '>' + str(target[0])[:-4] + '.sym']
	os.spawnv(os.P_WAIT, shell, args)

    def ActionString(self, target, source, env):
	return 'Making symbol file ' + str(target[0])[:-4] + '.sym'

    def Action(self, env):
	return env.Action(self.Run, self.ActionString)

class Strip:
    def Run(self, target, source, env):
	shell = os.environ['COMSPEC']
	args = [shell, '/c', 'strip.exe', str(target[0])]
	os.spawnv(os.P_WAIT, shell, args)

    def ActionString(self, target, source, env):
	return 'Stripping ' + str(target[0])

    def Action(self, env):
	return env.Action(self.Run, self.ActionString)

def MakeSymFile(env, target_info):
    "Make a DJGPP sym file."
    if target_info['compiler'] == 'djgpp':
	if target_info['build_type'] == 'debug':
	    return env.Action(Nm().Action(env))
	else:
	    return env.Action([Nm().Action(env), Strip().Action(env)])

class NlmPacker:
    def Run(self, target, source, env):
	shell = os.environ['COMSPEC']
	top = os.environ['TOP']
	nlm = str(target[0])
	packed = os.path.dirname(nlm) + '\\packed.bin'

	args = [shell, '/c', '%s\\build\\nwsdk\\tools\\nlmpackr.exe' % (top, ), nlm, packed]
	os.spawnv(os.P_WAIT, shell, args)

	args = [shell, '/c', 'del', nlm]
	os.spawnv(os.P_WAIT, shell, args)

	args = [shell, '/c', 'ren', packed, os.path.basename(nlm)]
	os.spawnv(os.P_WAIT, shell, args)

    def ActionString(self, target, source, env):
	return 'Packing ' + str(target[0])

    def Action(self, env):
	return env.Action(self.Run, self.ActionString)
    
def PackNLM(env):
    return env.Action(NlmPacker().Action(env))

class RunFixSE:
    def __init__(self, args):
	self.args = args

    def Run(self, target, source, env):
	shell = os.environ['COMSPEC']
	top = os.environ['TOP']
	exe = str(target[0])

	args = [shell, '/c', '%s\\build\\fixse\\fixse.exe' % (top, ), exe ] + self.args
	os.spawnv(os.P_WAIT, shell, args)

    def ActionString(self, target, source, env):
	return 'FixSE ' + str(target[0])

    def Action(self, env):
	return env.Action(self.Run, self.ActionString)

class CopyFile:
    def __init__(self, src, dest):
	self.src = src
	self.dest = dest

    def Run(self, target, source, env):
	shutil.copyfile(self.src, self.dest)

    def ActionString(self, target, source, env):
	return 'Copy %s -> %s' % (self.src, self.dest)

    def Action(self, env):
	return env.Action(self.Run, self.ActionString)

# The following replaces the spawn method used so that what would previously exceed the
# maximum command line length will now run
class replaceSpawn:
  def replacespawn(self, sh, escape, cmd, args, env):
    # this method currently only handles a single '||' in the command line args
    # and if it finds it will create two separate commands executing the second if
    # the first fails
    dblpipe = 0
    dblpipe_index = 0
    try:
      dblpipe_index = args.index('||')
      dblpipe = 1
    except ValueError:
      pass
            
    command = [cmd] + args[1:]
    lastargs = []
    if dblpipe:
      lastargs = command[dblpipe_index+1:]
      command = command[:dblpipe_index]

    rv, data, err = self.doSubprocess(string.join(command, ' '))
    if (rv > 0) and dblpipe:  
      rv, data, err = self.doSubprocess(string.join(lastargs, ' '))

    print data
    if rv:
      print err
    return rv

  def doSubprocess(self, cmdline):
    retvals = ()
    try:
      retvals = self.subprocess(cmdline)
    except WindowsError, (errno, strerror):
      # if we try and execute a system command we get a WindowsError (errno=2)
      # we need to execute it as an arg to cmd.exe
      cmdexe = os.path.join(self.replaceenv['ENV']['SYSTEMROOT'], 'system32', 'cmd.exe')
      retvals = self.subprocess(cmdexe + ' /c ' + cmdline)
    return retvals

  def subprocess(self, cmdline):
    startupinfo = subprocess.STARTUPINFO()
    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    proc = subprocess.Popen(cmdline, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
      stderr=subprocess.PIPE, startupinfo=startupinfo, shell = False)
    data, err = proc.communicate()
    return proc.wait(), data, err
    
def SetupSpawn(env):
  buf = replaceSpawn()
  buf.replaceenv = env
  env['SPAWN'] = buf.replacespawn

def GetVersion(env):
  return (env['MAJOR'], env['MINOR'], env['BUILDNUM'], env['REVISION'])
  
# sets env variables MAJOR, MINOR, BUILDNUM, and REVISION
def ParseVersionArgs(env):
  from SCons.Script.SConscript import SConsEnvironment
  SConsEnvironment.GetVersion = GetVersion

  from SCons.Script import ARGUMENTS
  versionstr = ARGUMENTS.get('version', None)
  
  if versionstr:
    # trim quotes if present
    major, minor, buildnum, revision = string.split(versionstr, '.')
    env['MAJOR'] = int(major)
    env['MINOR'] = int(minor)
    env['BUILDNUM'] = int(buildnum)
    env['REVISION'] = int(revision)
  else:
    env['MAJOR'] = int(ARGUMENTS.get('major', 7))
    env['MINOR'] = int(ARGUMENTS.get('minor', 1))
    env['BUILDNUM'] = int(ARGUMENTS.get('buildnum', 0))
    env['REVISION'] = int(ARGUMENTS.get('revision', 0))