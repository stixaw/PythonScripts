# Microsoft x64 cross compiler support, based on msvc.py, mslib,py, mslink.py

import SCons.Builder
import SCons.Tool
import SCons.Util
import msvc
import mslink

def generate(env):
    static_obj, shared_obj = SCons.Tool.createObjBuilders(env)
    for suffix in ['.c', '.C']:
        static_obj.add_action(suffix, SCons.Defaults.CAction)
        shared_obj.add_action(suffix, SCons.Defaults.ShCAction)
    for suffix in ['.cc', '.cpp', '.cxx', '.c++', '.C++']:
        static_obj.add_action(suffix, SCons.Defaults.CXXAction)
        shared_obj.add_action(suffix, SCons.Defaults.ShCXXAction)
    for suffix in ['.asm', '.ASM']:
	static_obj.add_action(suffix, SCons.Defaults.ASAction)
	shared_obj.add_action(suffix, SCons.Defaults.ASAction)
    SCons.Tool.createStaticLibBuilder(env)
    SCons.Tool.createSharedLibBuilder(env)
    SCons.Tool.createProgBuilder(env)

    # Asm
    env['AS']		= 'ml64'
    env['ASFLAGS']	= '-nologo'
    env['ASCOM']	= '$AS $ASFLAGS -c -Fo $TARGET $SOURCES'

    # C
    env['CC']		= 'cl'
    env['CCCOMFLAGS']	= '$CPPFLAGS $_CPPDEFFLAGS $_CPPINCFLAGS /c $SOURCES /Fo$TARGET $CCPCHFLAGS $CCPDBFLAGS'
    env['CCFLAGS']	= SCons.Util.CLVar('-nologo')
    env['CCCOM']	= '$CC $CCFLAGS $CCCOMFLAGS'
    env['CCPCHFLAGS']	= SCons.Util.CLVar(['${(PCH and "/Yu%s /Fp%s"%(PCHSTOP or "",File(PCH))) or ""}'])
    env['CCPDBFLAGS']	= SCons.Util.CLVar(['${(PDB and "/Z7") or ""}'])
    env['SHCC']		= '$CC'
    env['SHCCFLAGS']	= SCons.Util.CLVar('$CCFLAGS')
    env['SHCCCOM']	= '$SHCC $SHCCFLAGS $CCCOMFLAGS'
    env['OBJEMITTER']	= msvc.static_object_emitter
    env['SHOBJEMITTER'] = msvc.shared_object_emitter

    # C++
    env['CXX']		= '$CC'
    env['CXXFLAGS']	= SCons.Util.CLVar('$CCFLAGS $( -TP $)')
    env['CXXCOM']	= '$CXX $CXXFLAGS $CCCOMFLAGS'
    env['SHCXX']	= '$CXX'
    env['SHCXXFLAGS']	= SCons.Util.CLVar('$CXXFLAGS')
    env['SHCXXCOM']	= '$CXXCOM'

    # C preprocessor
    env['CPPDEFPREFIX']	= '-D'
    env['CPPDEFSUFFIX']	= ''
    env['INCPREFIX']	= '-I'
    env['INCSUFFIX']	= ''

    # Lib
    env['AR']		= 'lib'
    env['ARFLAGS']	= SCons.Util.CLVar('-nologo')
    env['ARCOM']	= "${TEMPFILE('$AR $ARFLAGS /OUT:$TARGET $SOURCES')}"
    env['LIBPREFIX']	= ''
    env['LIBSUFFIX']	= '.lib'

    # Rc
    env['RC']		= 'rc'
    env['RCFLAGS']	= SCons.Util.CLVar('')
    env['RCCOM']	= '$RC $_CPPDEFFLAGS $_CPPINCFLAGS $RCFLAGS /fo$TARGET $SOURCES'
    res_action = SCons.Action.Action('$RCCOM', '$RCCOMSTR')
    res_builder = SCons.Builder.Builder(action=res_action, suffix='.res',
					source_scanner=SCons.Tool.SourceFileScanner)
    SCons.Tool.SourceFileScanner.add_scanner('.rc', SCons.Defaults.CScan)
    env['BUILDERS']['RES'] = res_builder

    # Link
    env['LINK']		= 'link'
    env['LINKFLAGS']	= SCons.Util.CLVar('-nologo')
    env['LINKCOM']	= '${TEMPFILE("$LINK $LINKFLAGS -out:$TARGET $( $_LIBDIRFLAGS $) $_LIBFLAGS $_PDB $SOURCES")}'
    env['LIBDIRPREFIX']	= '-libpath:'
    env['LIBDIRSUFFIX']	= ''
    env['LIBLINKPREFIX']= ''
    env['LIBLINKSUFFIX']='$LIBSUFFIX'

    env['SHLINK']	= '$LINK'
    env['SHLINKFLAGS']	= SCons.Util.CLVar('$LINKFLAGS -dll')
    env['_SHLINK_TARGETS'] = mslink.windowsShlinkTargets
    env['_SHLINK_SOURCES'] = mslink.windowsShlinkSources
    env['SHLINKCOM']	= mslink.compositeLinkAction
    env['SHLIBEMITTER']	= mslink.windowsLibEmitter
    env['_PDB']		= mslink.pdbGenerator
    env['PROGEMITTER']	= mslink.prog_emitter

    env['WIN32DEFPREFIX']   = ''
    env['WIN32DEFSUFFIX']   = '.def'
    env['WIN32_INSERT_DEF'] = 0
    env['WINDOWSDEFPREFIX']      = '${WIN32DEFPREFIX}'
    env['WINDOWSDEFSUFFIX']      = '${WIN32DEFSUFFIX}'
    env['WINDOWS_INSERT_DEF']    = '${WIN32_INSERT_DEF}'

    env['WIN32EXPPREFIX']        = ''
    env['WIN32EXPSUFFIX']        = '.exp'
    env['WINDOWSEXPPREFIX']      = '${WIN32EXPPREFIX}'
    env['WINDOWSEXPSUFFIX']      = '${WIN32EXPSUFFIX}'

    env['WINDOWSSHLIBMANIFESTPREFIX'] = ''
    env['WINDOWSSHLIBMANIFESTSUFFIX'] = env['SHLIBSUFFIX'] + '.manifest'
    env['WINDOWSPROGMANIFESTPREFIX']  = ''
    env['WINDOWSPROGMANIFESTSUFFIX']  = env['PROGSUFFIX'] + '.manifest'

    # Misc
    env['CFILESUFFIX']	    = '.c'
    env['CXXFILESUFFIX']    = '.cpp'
    env['STATIC_AND_SHARED_OBJECTS_ARE_THE_SAME'] = 1

def exists(env):
    return env.Detect('ml64')
