# rename msi for solutoins


solname =''
class BuildError(Exception):
	def __init__(self, msg, *args):
		Exception.__init__(self, msg)
		self.msg = msg
		#apply(Exception.__init, (self,) + args)
def fail(msg):
	print '%s failed: %s' % (sys.argv[0], msg)
	sys.exit(1)
 

def ActivityCenter():
	src_dir = "c:\\output_msi"
	if os.path.exists(src_dir + "\\Altiris_ActivityCenter_7_0_x64.msi")
		os.rename(src_dir + "\\Altiris_ActivityCenter_7_0_x64.msi", src_dir + "\\Altiris_ActivityCenter_7_1_SP2_x64.msi")
	else:
		print ("({0})".format(e))

#This is the main program
if __name__ == '__main__':
	try:
		if solname == 'AC':
			ActivityCenter()
	except BuildError, e:
		fail(e.msg)