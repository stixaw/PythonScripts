import os
import sys


nerd_terms ={ 'GEEK':'someone who likes computers and lives in them',
		'NOOB': 'new geek'}
		

for term in nerd_terms:
	print term, '=', nerd_terms[term]
	