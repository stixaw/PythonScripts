import os
import sys
import time


TIM_STMP = time.strftime("%Y%m%d", time.gmtime())
print TIM_STMP