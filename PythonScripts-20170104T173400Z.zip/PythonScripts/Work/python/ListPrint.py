#!/usr/bin/env python
# encoding: utf-8
"""
untitled.py
"""

import sys
import os

WORD_LIST=[
	'Mark',
	'Angel',
	'Steve',
	'Steve 2',
	'Milt',
	'Bryant',
	'Cory'
	]

def Print(list):
	for F in list:
		print F


if __name__ == '__main__':
	Print(WORD_LIST)
