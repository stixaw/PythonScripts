import os
import sys


buildnum = '999'

print buildnum.zfill(3)