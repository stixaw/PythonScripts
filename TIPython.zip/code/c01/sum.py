#: c01:sum.py
def sum(arg1, arg2):
  return arg1 + arg2

print sum(42, 47)
print sum('spam ', "eggs")
#<hr>
output = '''
89
spam eggs
'''
