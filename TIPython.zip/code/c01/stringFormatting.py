#: c01:stringFormatting.py
val = 47
print "The number is %d" % val
val2 = 63.4
s = "val: %d, val2: %f" % (val, val2)
print s
#<hr>
output = '''
The number is 47
val: 47, val2: 63.400000
'''
